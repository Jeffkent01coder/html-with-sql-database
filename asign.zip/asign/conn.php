<?php
$errors = array();
$db = mysqli_connect("localhost", "root", "", "new");
if (!$db) {
  die("Connection failed: " . mysqli_connect_error());
}else{
  echo "connection successful";
}
if (isset($_POST['register'])) {
  $name = $_POST['name'];
  $idNo = $_POST['idNo'];
  $email = $_POST['email'];
  $password = $_POST['password'];

  if (empty($name)) {
    array_push($errors, "name required");
  }
  if (empty($idNo)) {
    array_push($errors, "ID required");
  }
  if (empty($email)) {
    array_push($errors, "email required");
  }
  if (empty($password)) {
    array_push($errors, "password required");
  }
  if (count($errors) == 0) {
    $sql = "INSERT INTO user (name, idNo, email, password) VALUES ('$name', '$idNo', '$email', '$password')";
    mysqli_query($db, $sql);
  }
}
?>